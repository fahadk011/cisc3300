// SPECIFICATION FILE		( SortedType.h )
#ifndef SORTEDLISTBYARRAY_H
#define SORTEDLISTBYARRAY_H
#define MAX_ITEM 100
#include "ItemType.h"

class SortedListByArray		// declares a class data type
{
public:

	SortedListByArray();

	void MakeEmpty();        // 8 public member functions
	void InsertItem(ItemType item);
	void DeleteItem(ItemType item);

	bool IsFull() const;
	bool IsEmpty() const;
	int GetLength() const;  // returns length of list
	void RetrieveItem(ItemType &item, bool &found);

	void ResetList();
	void GetNextItem(ItemType &item);

	//sets an item to the location
	void SetItem(int index, ItemType item) {
		if (index >= 0 && index < MAX_ITEM) {
			info[index] = item;
		}
	}

	//gets the item at the given location
	ItemType GetItem(int index) const {
		if (index >= 0 && index < length) {
			return info[index];
		}
		return ItemType();
	}
	//sets the length
	void SetLength(int len) {
		length = len;
	}

private:
	int length;
	ItemType info[MAX_ITEM];
	int currentPos;
};

#endif
