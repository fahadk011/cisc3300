#ifndef SORTEDLIST_H
#define SORTEDLIST_H

#include "SortedListByArray.h"

class SortedList {
public:
    SortedListByArray merger;

    //merge two SortedListByArray objects into this SortedList
    void MergeList(SortedListByArray &listOne, SortedListByArray &listTwo);

    //display the merged list
    void DisplayList();

};
#endif
