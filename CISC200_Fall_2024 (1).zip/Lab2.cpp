#include <iostream>
#include "SortedList.h"

int main() {
	SortedListByArray listOne, listTwo;
	SortedList mergedSortedList;

	//insert items into listOne
	listOne.InsertItem(ItemType(0));
	listOne.InsertItem(ItemType(1));
	listOne.InsertItem(ItemType(3));
	listOne.InsertItem(ItemType(10));

	//insert items into listTwo
	listTwo.InsertItem(ItemType(5));
	listTwo.InsertItem(ItemType(11));
	listTwo.InsertItem(ItemType(12));

	//display contents of listOne
	std::cout << "List One: ";
	ItemType item;
	listOne.ResetList();
	for (int i = 0; i < listOne.GetLength(); i++) {
		listOne.GetNextItem(item);
		std::cout << item.GetValue() << " ";
	}
	std::cout << std::endl;

	//display contents of listTwo
	std::cout << "List Two: ";
	listTwo.ResetList();
	for (int i = 0; i < listTwo.GetLength(); i++) {
		listTwo.GetNextItem(item);
		std::cout << item.GetValue() << " ";
	}
	std::cout << std::endl;

	// Merge listOne and listTwo into mergedSortedList
	mergedSortedList.MergeList(listOne, listTwo);

	// Display the merged list
	std::cout << "Merged List: ";
	mergedSortedList.DisplayList();

	return 0;
}
