#include "ItemType.h"
#include <iostream>

ItemType::ItemType() :
		value(0) {
}

ItemType::ItemType(int value) :
		value(value) {
}

Evaluation ItemType::ComparedTo(ItemType &otherItem) const {
	if (value < otherItem.value)
		return LESS;
	else if (value > otherItem.value)
		return GREATER;
	else
		return EQUAL;
}

int ItemType::GetValue() const{
	return value;
}

void ItemType::SetValue(int value) {
	this->value = value;
}
