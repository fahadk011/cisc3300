#ifndef ITEMTYPE_H
#define ITEMTYPE_H

#include <iostream>

//enum to define the constants
enum Evaluation { LESS, GREATER, EQUAL };

class ItemType
{
public:
    ItemType();
    ItemType(int value);
    int GetValue() const;
    void SetValue(int value);
    Evaluation ComparedTo(ItemType &other) const;

    //output stream of the class
    friend std::ostream &operator<<(std::ostream &os, const ItemType &item);

private:
    int value;
};

#endif
