 #include "SortedList.h"

void SortedList::MergeList(SortedListByArray &listOne, SortedListByArray &listTwo) {
    //clear the merged list
    merger.MakeEmpty();

    //reset the list iterations
    int indexOne = 0, indexTwo = 0;
    listOne.ResetList();
    listTwo.ResetList();

    ItemType itemOne, itemTwo;

    //fetch first items from both lists
    if (listOne.GetLength() > 0) listOne.GetNextItem(itemOne);
    if (listTwo.GetLength() > 0) listTwo.GetNextItem(itemTwo);

    int mergeIndex = 0;

    //loop and add the items from both lists
    while (indexOne < listOne.GetLength() && indexTwo < listTwo.GetLength()) {
        if (itemOne.ComparedTo(itemTwo) == LESS) {
            merger.SetItem(mergeIndex++, itemOne);
            indexOne++;
            if (indexOne < listOne.GetLength())
                listOne.GetNextItem(itemOne);

        } else {
            merger.SetItem(mergeIndex++, itemTwo);
            indexTwo++;
            if (indexTwo < listTwo.GetLength())
                listTwo.GetNextItem(itemTwo);

        }
    }

    //append any remaining items from listOne
    while (indexOne < listOne.GetLength()) {
        merger.SetItem(mergeIndex++, itemOne);
        indexOne++;
        if (indexOne < listOne.GetLength())
            listOne.GetNextItem(itemOne);

    }

    //append any remaining items from listTwo
    while (indexTwo < listTwo.GetLength()) {
        merger.SetItem(mergeIndex++, itemTwo);
        indexTwo++;
        if (indexTwo < listTwo.GetLength())
            listTwo.GetNextItem(itemTwo);

    }

    merger.SetLength(mergeIndex);
}


// Helper function to display the list
void SortedList::DisplayList() {
    ItemType item;
    merger.ResetList();
    for (int i = 0; i < merger.GetLength(); i++) {
        merger.GetNextItem(item);
        std::cout << item.GetValue() << " ";
    }
    std::cout << std::endl;
}
